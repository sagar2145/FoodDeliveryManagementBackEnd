package pack.serviceimpl;

import java.util.List;

import javax.persistence.Query;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pack.entity.Driver;
import pack.service.DriverService;

@Service
public class DriverServiceImpl implements DriverService {

	@Autowired
	private SessionFactory sessionFactory;
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;}
	private Session session;
	private Transaction transaction;


	//add details of driver
	public String saveDriver(Driver driver) {
		try {
			session = sessionFactory.openSession();
			transaction= session.beginTransaction();
			session.save(driver);
			transaction.commit();
			return "driver added";}
		catch (Exception e) {
			transaction.rollback();
			return " Driver already exists";}
		finally{
			session.close();}
	}


	//get details of driver
	public List<Driver> driverList() {
		session = this.sessionFactory.openSession();
		transaction = session.beginTransaction();
		List<Driver> driversList = session.createCriteria(Driver.class).list();
		transaction.commit();
		session.close();
		return driversList;}


	//driver login
	@Override
	public String getDriverLogin(String email, String password) {
		try{
			session = sessionFactory.openSession();
			Driver driver = session.get(Driver.class, email);
			if (password.equals(driver.getPassword())) {
				return "login Success";
			} else {
				return "login failed";
			}}
		catch(Exception e){
			return "enter valid user name";}
		finally{
			session.close();}}


	//get driver by username
	@Override
	public Driver getDriverByMail(String email) {
		try{
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			return  session.get(Driver.class, email);}
		catch(Exception e){
			return null;
		}
		finally{
			session.close();}}


	//update driver password
	@Override
	public String updateDriverPassword(String email, String pasword) {
		try{session = sessionFactory.openSession();
		transaction = session.beginTransaction();
		Driver driver=session.get(Driver.class, email);
		driver.setPassword(pasword);
		transaction.commit();
		return "password updated";}
		catch(Exception e){
			transaction.rollback();
			return "password not updated";}
		finally{
			session.close();
		}}


	//get drivers available for order
	@Override
	public List<Driver> getDriverByMailForOrder() {
		try{
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			int	id=0;
			@SuppressWarnings("unchecked")
			List<Driver> drivers=  session.createQuery("from Driver where orderId="+id).list();
			return drivers;
		}
		catch(Exception e){
			return null;
		} 
		finally{
			session.close();}}


	//delete driver
	@Override
	public String deleteDriverDetails(String mail) {
		try {
			session = sessionFactory.openSession();
			transaction= session.beginTransaction();
			Driver driver=session.get(Driver.class, mail);
			session.delete(driver);
			transaction.commit();
			return "driver deleted";}
		catch (Exception e) {
			transaction.rollback();
			return "failed to delete driver";}
		finally{
			session.close();}
	}

	//update driver password using old password
	@Override
	public String updateDriverOldPassword(String email, String password, String newPass) {
		try{session = sessionFactory.openSession();
		transaction = session.beginTransaction();
		Driver driver=session.get(Driver.class, email);
		if(driver.getPassword().equals(password)){		
			driver.setPassword(newPass);
			transaction.commit();
			return "password updated";}
		return "enter correct password";}
		catch(Exception e){
			transaction.rollback();
			return "password not updated";}
		finally{
			session.close();
		}}

}
