package pack.serviceimpl;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pack.entity.Admin;
import pack.entity.Driver;
import pack.entity.FoodItems;
import pack.entity.Orders;
import pack.entity.Restaurants;
import pack.service.AdminService;

@Service
public class AdminServiceImpl implements AdminService {

	@Autowired
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	private Session session;
	private Transaction transaction;

	//***************restaurant and food items********************************
	// add only restaurant details
	@Override
	public String addRestaurant(Restaurants restaurants) {
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			session.save(restaurants);
			transaction.commit();
			return "restaurant added";
		} catch (Exception e) {
			transaction.rollback();
			return "Restaurant already exists";
		} finally {
			session.close();
		}
	}


	// get all restaurants list
	public List<Restaurants> getRestaurantsList() {
		session = this.sessionFactory.openSession();
		List<Restaurants> restaurantsList = session.createCriteria(Restaurants.class).list();
		return restaurantsList;
	}


	// get restaurant by id
	@Override
	public Restaurants getRestaurant(int restaurantId) {
		session = this.sessionFactory.openSession();
		transaction = session.beginTransaction();
		Restaurants restaurants = session.get(Restaurants.class, restaurantId);
		transaction.commit();
		return restaurants;
	}


	// adding food items to a table
	@Override
	public String foodItemsToRestaurant(Restaurants restaurants) {
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			for (int i = 0; i < restaurants.getFoodList().size(); i++) {
				restaurants.getFoodList().get(i).setRestaurants(restaurants);
				session.save(restaurants.getFoodList().get(i));
			}
			transaction.commit();
			return "item(s) added";
		} catch (Exception e) {
			transaction.rollback();
			return "item(s) not added";
		} finally {
			session.close();
		}
	}


	// get food list
	@SuppressWarnings("unchecked")
	@Override
	public List<FoodItems> getFoodList(Restaurants restaurants) {
		session = sessionFactory.openSession(); 
		transaction = session.beginTransaction();
		List<Object[]> items =
				session.createNativeQuery("SELECT \"foodName\",	\"foodPrize\"FROM \"SYSTEM\".\"FoodItems\" where \"restaurantId\"='"+restaurants.getRestaurantId()+"'").list();
		List<FoodItems> list= new ArrayList<>();
		for (Object[] obj : items) {
			FoodItems foodItems= new FoodItems();
			foodItems.setFoodName((String) obj[0]);
			foodItems.setFoodPrize((String) obj[1]);
			list.add(foodItems); 
		}
		transaction.commit();
		return list;} 

	// delete food items in a restaurant 
	@Override
	public String deleteFoodItems(Restaurants restaurants) {

		session = sessionFactory.openSession();
		transaction = session.beginTransaction();
		int j=restaurants.getRestaurantId();
		NativeQuery<FoodItems> query =
				session.createSQLQuery("delete from \"SYSTEM\".\"FoodItems\" where \"restaurantId\"="+j);
		query.executeUpdate();
		transaction.commit();
		return "deleted";
	}


	// edit restaurant details
	@Override
	public String editRestaurant(Restaurants restaurants) {
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			Restaurants restaurant = session.get(Restaurants.class, restaurants.getRestaurantId());
			if (restaurants.getImage() != null)
				restaurant.setImage(restaurants.getImage());
			if (restaurants.getRating() != null)
				restaurant.setRating(restaurants.getRating());
			if (restaurants.getRestaurantPhone() != null)
				restaurant.setRestaurantPhone(restaurants.getRestaurantPhone());
			if (restaurants.getRestaurantAddress() != null)
				restaurant.setRestaurantAddress(restaurants.getRestaurantAddress());
			if (restaurants.getRestaurantName() != null)
				restaurant.setRestaurantName(restaurants.getRestaurantName());

			session.update(restaurant);
			transaction.commit();
			return "restaurant updated";
		} catch (Exception e) {
			transaction.rollback();
			return "Restaurant not updated";
		} finally {
			session.close();
		}
	}

	// edit only food list with restaurant id #########
	@Override
	public String editFoodList(Restaurants restaurants) {
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			Restaurants restaurant = session.get(Restaurants.class, restaurants.getRestaurantId());
			NativeQuery<FoodItems> query =
					session.createSQLQuery("delete from \"SYSTEM\".\"FoodItems\" where \"restaurantId\"="+restaurants.getRestaurantId());
			query.executeUpdate();
			transaction.commit();

			foodItemsToRestaurant(restaurants) ;

			return "food list updated";
		} catch (Exception e) {
			transaction.rollback();
			System.err.println();
			return "food list not updated";
		} finally {
			session.close();
		}
	}



	// delete Restuarant & food list
	@Override
	public String deleteRestaurant(int id) {
		session = sessionFactory.openSession();
		transaction = session.beginTransaction();
		NativeQuery<FoodItems> query =
				session.createSQLQuery("delete from \"SYSTEM\".\"FoodItems\" where \"restaurantId\"="+id);
		query.executeUpdate();
		Restaurants restaurant = session.get(Restaurants.class, id);
		session.delete(restaurant);
		transaction.commit();
		return "deleted";
	}


	// ******************** order methods***********************
	// time method
	public Timestamp getTime() {
		Timestamp time = new Timestamp(System.currentTimeMillis());
		return time;
	}


	// add and set order details
	@Override
	public String addOrderDetails(Orders orders) {
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
		
			orders.setAssign("not assigned");
			orders.setStatus("Pending");
			orders.setOrderTime(getTime());
			session.save(orders);
			transaction.commit();
			return "order placed";
		} catch (Exception e) {
			transaction.rollback();
			return "order not placed";
		} finally {
			session.close();
		}
	}


	// get order details
	@Override
	public List<Orders> getOrderList() {
		session = this.sessionFactory.openSession();
		transaction = session.beginTransaction();
		List<Orders> orderList = session.createCriteria(Orders.class).list();
		transaction.commit();
		session.close();
		return orderList;
	}


	// get order details by id
	@Override
	public Orders orderById(int orderId) {
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			return session.get(Orders.class, orderId);
		} catch (Exception e) {
			System.err.println();
			return null;
		} finally {
			session.close();
		}
	}


	// set order status delivery and time
	@Override
	public String setOrderStatus(int orderId) {
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			Orders orderStatus = session.get(Orders.class, orderId);
			orderStatus.setStatus("delivered");
			orderStatus.setDeliveredTime(getTime());
			session.save(orderStatus);
			transaction.commit();
			resetOrderIdToDriver(orderStatus.getDriverEmail());
			return "order updated";
		} catch (Exception e) {
			transaction.rollback();
			return "ordere not updated";
		} finally {
			session.close();
		}
	}
	// resetting the driver order id(mapped to above method
	public void resetOrderIdToDriver(String mail) {
		session = sessionFactory.openSession();
		transaction = session.beginTransaction();
		Driver driver = session.get(Driver.class, mail);
		driver.setOrderId(0);
		transaction.commit();
		session.close();
	}


	// assigning order to driver by admin
	@Override
	public String setAssignDriver(int orderId, String driverEmail) {
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			Orders assignOrder = session.get(Orders.class, orderId);
			assignOrder.setAssign("assigned");
			assignOrder.setStatus("on the way");
			if(assignOrder.getDriverEmail()!=null){
				return "already assigned";
			}
			assignOrder.setDriverEmail(driverEmail);
			// session.save(assignOrder);
			transaction.commit();
			setOrderIdToDriver(orderId, driverEmail);
			return "order assigned";
		} catch (Exception e) {
			transaction.rollback();
			return "failed to assign order";
		} finally {
			session.close();
		}
	}
	// showing driver the order id(mapped to above method
	public void setOrderIdToDriver(int id, String mail) {
		session = sessionFactory.openSession();
		transaction = session.beginTransaction();
		Driver driver = session.get(Driver.class, mail);
		driver.setOrderId(id);
		transaction.commit();
		session.close();
	}


	// ********Admin personal details*******************************
	// add admin details to admin table
	@Override
	public String addAdmin(Admin admin) {
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			session.save(admin);
			transaction.commit();
			return "admin details added";
		} catch (Exception e) {
			transaction.rollback();
			return "admin already exists";
		} finally {
			session.close();
		}
	}


	// get admins list
	@Override
	public List<Admin> adminList() {
		session = this.sessionFactory.openSession();
		transaction = session.beginTransaction();
		List<Admin> adminsList = session.createCriteria(Admin.class).list();
		transaction.commit();
		session.close();
		return adminsList;
	}


	// get admin login
	@Override
	public String getAdminLogin(String adminEmail, String adminPassword) {
		try {
			session = sessionFactory.openSession();
			Admin admin = session.get(Admin.class, adminEmail);
			if (adminPassword.equals(admin.getAdminPassword())) {
				return "login Success";
			} else {
				return "login failed";
			}
		} catch (Exception e) {
			return "enter valid user name";
		} finally {
			session.close();
		}
	}


	// get admin by username
	@Override
	public Admin adminByMail(String adminEmail) {
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			return session.get(Admin.class, adminEmail);
		} catch (Exception e) {
			return null;
		} finally {
			session.close();
		}
	}


	//delete admin details
	@Override
	public String deleteAdminDetails(String mail) {
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			Admin admin=session.get(Admin.class, mail);
			session.delete(admin);
			transaction.commit();
			return "admin deleted";
		} catch (Exception e) {
			transaction.rollback();
			return "failed to delete admin";
		} finally {
			session.close();
		}
	}


	//update admin password
	@Override
	public String updateAdminPassword(String adminEmail, String adminPassword) {
		try{session = sessionFactory.openSession();
		transaction = session.beginTransaction();
		Admin admin=session.get(Admin.class, adminEmail);
		admin.setAdminPassword(adminPassword);
		transaction.commit();
		return "password updated";}
		catch(Exception e){
			transaction.rollback();
			return "password not updated";}
		finally{
			session.close();
		}}

	//update ADMIN  password with old password
	@Override
	public String updateAdminOldPassword(String adminEmail, String adminPassword, String newPass) {
		try{session = sessionFactory.openSession();
		transaction = session.beginTransaction();
		Admin admin=session.get(Admin.class, adminEmail);
		if(admin.getAdminPassword().equals(adminPassword)){		
			admin.setAdminPassword(newPass);
			transaction.commit();
			return "password updated";}
		return "enter correct password";}
		catch(Exception e){
			transaction.rollback();
			return "password not updated";}
		finally{
			session.close();
		}}
}
