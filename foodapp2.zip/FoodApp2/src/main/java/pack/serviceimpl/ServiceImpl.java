package pack.serviceimpl;

import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import pack.entity.Customer;
import pack.service.CustomerService;

@Service
public class ServiceImpl implements CustomerService {
	@Autowired
	private SessionFactory sessionFactory;
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;}

	private Session session;
	private Transaction transaction;


	//save customer
	public String saveCustomer(Customer customer) {
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			session.save(customer);
			transaction.commit();
			return "customer added";
		}
		catch (Exception e) {
			transaction.rollback();
			return "customer already exists";}
		finally{
			session.close();
		}}


	//get customers list
	@SuppressWarnings("unchecked")
	public List<Customer> customerList() {
		session = this.sessionFactory.openSession();
		transaction = session.beginTransaction();
		List<Customer> customersList = session.createCriteria(Customer.class).list();
		transaction.commit();
		session.close();
		return customersList;}


	//customer login
	public String getCustomerLogin(String email, String password) {
		try{
			session = sessionFactory.openSession();
			Customer customer = session.get(Customer.class, email);
			if (password.equals(customer.getPassWord())) {
				return "login Success";
			} else {
				return "login failed";
			}}
		catch(Exception e){
			return "enter valid user name";}
		finally{
			session.close();}}


	//get customer by mail
	public Customer getCustomerByMail(String mail) {
		try{
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			return  session.get(Customer.class, mail);}
		catch(Exception e){
			return null;
		}
		finally{
			session.close();}}


	//update customer password
	@Override
	public String updateCustomerPassword(String email, String password) {
		try{session = sessionFactory.openSession();
		transaction = session.beginTransaction();
		Customer customer=session.get(Customer.class, email);
		customer.setPassWord(password);
		transaction.commit();
		return "password updated";}
		catch(Exception e){
			transaction.rollback();
			return "password not updated";}
		finally{
			session.close();
		}}


	//delete customers details
	@Override
	public String deleteCustomerDetails(String email) {
		try {
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			Customer customer=session.get(Customer.class, email);
			session.delete(customer);
			transaction.commit();
			return "customer deleted";
		}
		catch (Exception e) {
			transaction.rollback();
			return "failed to to delete customer";}
		finally{
			session.close();
		}}

	//update customer password using old password
	@Override
	public String updateCustomerOldPassword(String mail, String oldPass, String newPass) {
		try{session = sessionFactory.openSession();
		transaction = session.beginTransaction();
		Customer customer=session.get(Customer.class, mail);
		if(customer.getPassWord().equals(oldPass)){		
			customer.setPassWord(newPass);
			transaction.commit();
			return "password updated";}
		return "enter correct password";}
		catch(Exception e){
			transaction.rollback();
			return "password not updated";}
		finally{
			session.close();
		}}

}
