package pack.service;

import java.util.List;
import pack.entity.Admin;
import pack.entity.FoodItems;
import pack.entity.Orders;
import pack.entity.Restaurants;

public interface AdminService {

	public List<Restaurants> getRestaurantsList();

	public String addOrderDetails(Orders orders);

	public Orders orderById(int orderId);

	public List<Orders> getOrderList();

	public String setOrderStatus(int orderId);

	public String setAssignDriver(int orderId, String driverEmail);

	public List<FoodItems> getFoodList(Restaurants restaurants);

	public String addAdmin(Admin admin);

	public List<Admin> adminList();

	public String getAdminLogin(String adminEmail, String adminPassword);

	public Admin adminByMail(String adminEmail);

	public String foodItemsToRestaurant(Restaurants restaurants);

	public String editRestaurant(Restaurants restaurants);

	public String editFoodList(Restaurants restaurants);

	public String deleteRestaurant(int id);

	public String addRestaurant(Restaurants restaurants);

	public String deleteFoodItems(Restaurants restaurants);

	public Restaurants getRestaurant(int restaurantId);

	public String deleteAdminDetails(String mail);

	public String updateAdminPassword(String adminEmail, String adminPassword);

	public String updateAdminOldPassword(String adminEmail, String adminPassword, String newPass);

}
