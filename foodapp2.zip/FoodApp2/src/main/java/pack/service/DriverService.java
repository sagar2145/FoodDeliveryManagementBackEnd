package pack.service;

import java.util.List;

import pack.entity.Driver;

public interface DriverService {

	String saveDriver(Driver driver);

	List<Driver> driverList();

	String getDriverLogin(String email, String password);

	Driver getDriverByMail(String email);

	String updateDriverPassword(String email, String pasword);

	List<Driver> getDriverByMailForOrder();

	String deleteDriverDetails(String mail);

	String updateDriverOldPassword(String email, String password, String newPass);

}
