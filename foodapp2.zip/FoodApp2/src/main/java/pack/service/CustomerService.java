package pack.service;

import java.util.List;

import pack.entity.Customer;

public interface CustomerService {

	public String saveCustomer(Customer customer);

	public List<Customer> customerList();

	public String getCustomerLogin(String email, String passWord);

	public Customer getCustomerByMail(String mail);

	public String updateCustomerPassword(String email, String passWord);

	public String deleteCustomerDetails(String email);

	public String updateCustomerOldPassword(String mail, String oldPass, String newPass);
}
