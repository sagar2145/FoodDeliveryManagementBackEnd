package pack.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import pack.entity.Driver;
import pack.service.DriverService;
@RestController
@RequestMapping(value = "/driver")
public class DriverController {

	@Autowired
	DriverService driverService;


	//save driver details
	@RequestMapping(value = "/save", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public String saveDriver(@RequestBody Driver driver) {
		String message=driverService.saveDriver(driver);
		return message;}

	//get driver details
	@RequestMapping(value = "/getdriv", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Driver> driversList() {
		return driverService.driverList();}


	//login driver
	@RequestMapping(value = "/login", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String driversLogin(@RequestBody Driver driver) {
		return driverService.getDriverLogin(driver.getEmail(),driver.getPassword());}

	//get driver by user name
	@RequestMapping(value = "/getDrivBy", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public Driver getDriverByMail(@RequestBody Driver driver) {
		return driverService.getDriverByMail(driver.getEmail());}

	//get driver by user name if no orders
	@RequestMapping(value = "/getDrivByIfNoOrder", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Driver> getDriverByMailIfNoOrder() {
		return driverService.getDriverByMailForOrder();} 

	//update password of drivers
	@RequestMapping(value = "/passwordUpdate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String updateDriverPassword(@RequestBody Driver driver) {
		return driverService.updateDriverPassword(driver.getEmail(), driver.getPassword());}


	//update password of driver using old password
	@RequestMapping(value = "/passUpdate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String updateDriverOldPassword(@RequestBody Driver driver) {
		return driverService.updateDriverOldPassword(driver.getEmail(), driver.getPassword(),driver.getNewPass());}



	//delete driver
	@RequestMapping(value = "/deleteDriv", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String deleteDriver(@RequestBody Driver driver) {
		return driverService.deleteDriverDetails(driver.getEmail());}


}
