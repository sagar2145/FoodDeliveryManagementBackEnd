package pack.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import pack.entity.Customer;
import pack.service.CustomerService;

@RestController
@RequestMapping(value = "/customer")
public class CustomerController {

	@Autowired
	CustomerService customerService;


	//save customers details
	@RequestMapping(value = "/save", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public String saveCustomer(@RequestBody Customer customer) {
		String message=customerService.saveCustomer(customer);
		return message;}

	//get customers details
	@RequestMapping(value = "/getcust", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Customer> customersList() {
		return customerService.customerList();}


	//login customers
	@RequestMapping(value = "/login", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String customersLogin(@RequestBody Customer customer) {
		return customerService.getCustomerLogin(customer.getEmail(),customer.getPassWord());}


	//get customers by user name
	@RequestMapping(value = "/getCustBy", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public Customer getCustomerByMail(@RequestBody Customer customer) {
		return customerService.getCustomerByMail(customer.getEmail());}


	//update password of customers
	@RequestMapping(value = "/passwordUpdate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String updateCustomerPassword(@RequestBody Customer customer) {
		return customerService.updateCustomerPassword(customer.getEmail(), customer.getPassWord());}


	//update password of customers using old password
	@RequestMapping(value = "/passUpdate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String updateCustomerOldPassword(@RequestBody Customer customer) {
		return customerService.updateCustomerOldPassword(customer.getEmail(),customer.getPassWord(),customer.getNewPass());}


	//delete customers
	@RequestMapping(value = "/deleteCust", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String deleteCustomer(@RequestBody Customer customer) {
		return customerService.deleteCustomerDetails(customer.getEmail());}



}
