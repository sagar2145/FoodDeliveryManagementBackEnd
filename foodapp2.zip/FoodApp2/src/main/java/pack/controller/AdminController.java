package pack.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import pack.entity.Admin;
import pack.entity.FoodItems;
import pack.entity.Orders;
import pack.entity.Restaurants;
import pack.service.AdminService;

@RestController
@RequestMapping(value = "/admin")
public class AdminController {

	@Autowired 
	AdminService adminService;


	//add only restaurants 
	@RequestMapping(value = "/addRest", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public String addRestaurant(@RequestBody Restaurants restaurants) {
		return	adminService.addRestaurant(restaurants);}


	//get restaurants details(without food list
	@RequestMapping(value = "/getRest", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Restaurants> restaurantsList() {
		return adminService.getRestaurantsList();}


	//get restaurants details by id  (without food list
	@RequestMapping(value = "/getRestById", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public Restaurants getRestaurantById(@RequestBody Restaurants restaurants) {
		return adminService.getRestaurant(restaurants.getRestaurantId());}


	//edit only restaurants details**********(working good
	@RequestMapping(value = "/editRest", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public String editRestaurantDetails(@RequestBody Restaurants restaurants) {
		return	adminService.editRestaurant(restaurants);}




	//edit only foodlist*********(working  
	@RequestMapping(value = "/editFood", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public String editFoodDetails(@RequestBody Restaurants restaurants) {
		return	adminService.editFoodList(restaurants);}

	//delete Restaurant  ******(working good 
	@RequestMapping(value = "/deleteRest", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public String deleteResturantDetails(@RequestBody Restaurants restaurants) {
		return	adminService.deleteRestaurant(restaurants.getRestaurantId());}

	//add food items to a restaurant ***(working good
	@RequestMapping(value = "/addFood", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public String addFoodItemsToRestaurant(@RequestBody Restaurants restaurants) {
		return	adminService.foodItemsToRestaurant(restaurants);
	}	


	//get foodlist
	@RequestMapping(value = "/getFoodList", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public List<FoodItems> foodList(@RequestBody Restaurants restaurants){
		return adminService.getFoodList(restaurants);
	}


	//delete  food items w.r.t restaurant id
	@RequestMapping(value = "/deleteFood", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public String deleteFoodItemsInRestaurant(@RequestBody Restaurants restaurants) {
		return	adminService.deleteFoodItems(restaurants);
	}



	//add orders to db
	@RequestMapping(value = "/setOrder", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public String orderDetails(@RequestBody  Orders orders) {
		return	adminService.addOrderDetails(orders);
	}


	//get order details
	@RequestMapping(value = "/getorder", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Orders> orderList() {
		return adminService.getOrderList();}

	//get orders by id
	@RequestMapping(value = "/getOrderBy", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public Orders getOrderById(@RequestBody Orders orders) {
		return adminService.orderById(orders.getOrderId());}



	//set delivery status to order
	@RequestMapping(value = "/orderStatus", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public String orderStatus(@RequestBody  Orders orders) {
		return	adminService.setOrderStatus(orders.getOrderId());
	}

	//assign driver to order by admin
	@RequestMapping(value = "/assignOrder", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public String assignDriver(@RequestBody  Orders orders){
		return	adminService.setAssignDriver(orders.getOrderId(),orders.getDriverEmail());}



	//admin personal details******************
	//add admin details
	@RequestMapping(value = "/addAdmin", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE, consumes = MediaType.APPLICATION_JSON_VALUE)
	public String addAdminDetails(@RequestBody Admin admin) {
		return	adminService.addAdmin(admin);}

	//get admin details
	@RequestMapping(value = "/getAdmin", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<Admin> getAdminsList() {
		return adminService.adminList();}

	//Admins login
	@RequestMapping(value = "/login", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String adminLogin(@RequestBody Admin admin) {
		return adminService.getAdminLogin(admin.getAdminEmail(),admin.getAdminPassword());}


	//get admin by username
	@RequestMapping(value = "/getAdminBy", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public Admin getAdminByMail(@RequestBody Admin admin) {
		return adminService.adminByMail(admin.getAdminEmail());}


	//update password of customers
	@RequestMapping(value = "/passwordUpdate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String updateAdminPassword(@RequestBody Admin admin) {
		return adminService.updateAdminPassword(admin.getAdminEmail(), admin.getAdminPassword());}


	//update password of Admin using old password
	@RequestMapping(value = "/passUpdate", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String updateAdminOldPassword(@RequestBody Admin admin) {
		return adminService.updateAdminOldPassword(admin.getAdminEmail(), admin.getAdminPassword(),admin.getNewPass());}



	//delete admin
	@RequestMapping(value = "/deleteAdmin", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
	public String deleteAdmin(@RequestBody Admin admin) {
		return adminService.deleteAdminDetails(admin.getAdminEmail());}


}
