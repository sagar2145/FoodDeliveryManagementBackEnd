package pack.entity;
import java.io.Serializable;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name="RestaurantTab")
public class Restaurants implements Serializable {

	@Id
	@GenericGenerator(name="inc",strategy="increment")
	@GeneratedValue(generator="inc")
	@Column(name="restaurantId")
	private int restaurantId;

	@Column(name="restaurantName")
	private String restaurantName;

	@Column(name="restaurantAddress")
	private String restaurantAddress;

	@Column(name="rating")
	private String rating;

	@Column(name="restaurantPhone",unique=true)
	private String restaurantPhone;

	@Column(name="image")
	private String image;


	@OneToMany(fetch = FetchType.LAZY, cascade=CascadeType.ALL)
	private List<FoodItems> foodList; 



	public String getRestaurantPhone() {
		return restaurantPhone;
	}
	public void setRestaurantPhone(String restaurantPhone) {
		this.restaurantPhone = restaurantPhone;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public int getRestaurantId() {
		return restaurantId;
	}
	public List<FoodItems> getFoodList() {
		return foodList;
	}
	public void setFoodList(List<FoodItems> foodList) {
		this.foodList = foodList;
	}
	public void setRestaurantId(int restaurantId) {
		this.restaurantId = restaurantId;
	}
	public String getRestaurantName() {
		return restaurantName;
	}
	public void setRestaurantName(String restaurantName) {
		this.restaurantName = restaurantName;
	}
	public String getRestaurantAddress() {
		return restaurantAddress;
	}
	public void setRestaurantAddress(String restaurantAddress) {
		this.restaurantAddress = restaurantAddress;
	}
	public String getRating() {
		return rating;
	}
	public void setRating(String rating) {
		this.rating = rating;
	}
	@Override
	public String toString() {
		return "Restaurants [restaurantId=" + restaurantId + ", restaurantName=" + restaurantName
				+ ", restaurantAddress=" + restaurantAddress + ", rating=" + rating + ", restaurantPhone="
				+ restaurantPhone + ", image=" + image + ", foodList=" + foodList + "]";
	}


}
