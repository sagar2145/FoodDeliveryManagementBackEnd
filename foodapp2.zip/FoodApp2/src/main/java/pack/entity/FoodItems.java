package pack.entity;
import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name="FoodItems")
public class FoodItems implements Serializable{

	@Id
	@GenericGenerator(name="inc",strategy="increment")
	@GeneratedValue(generator="inc")
	@Column(name="foodId")
	private int foodId;

	@Column(name="foodName")
	private String foodName;

	@Column(name="foodPrize")
	private String foodPrize;

	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "restaurantId", nullable = false)
	private Restaurants restaurants; 


	public Restaurants getRestaurants() {
		return restaurants;
	}
	public void setRestaurants(Restaurants restaurants) {
		this.restaurants = restaurants;
	}
	public int getFoodId() {
		return foodId;
	}
	public void setFoodId(int foodId) {
		this.foodId = foodId;
	}
	public String getFoodName() {
		return foodName;
	}
	public void setFoodName(String foodName) {
		this.foodName = foodName;
	}
	public String getFoodPrize() {
		return foodPrize;
	}
	public void setFoodPrize(String foodPrize) {
		this.foodPrize = foodPrize;
	}
	@Override
	public String toString() {
		return "FoodItems [foodId=" + foodId + ", foodName=" + foodName + ", foodPrize=" + foodPrize + ", restaurants="
				+ restaurants + "]";
	}

}
